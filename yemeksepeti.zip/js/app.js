document.addEventListener("DOMContentLoaded", function(event) { 
  TemplateModule.init();
  CartModule.init();
});
